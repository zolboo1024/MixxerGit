Mixxer App

This is the GitHub for the Mixxer App. The app is published as a beta version on the Google Play Store:
https://play.google.com/store/apps/details?id=edu.dickinson.newmixxer

The app is a simple way of accessing the website from a phone. It has login functionality and then directs the user to a mobile-optimized version of the website.

App developed by:


Zolboo Erdenebaatar (https://www.linkedin.com/in/zolboo-erdenebaatar-690492160/)

Olivia Voler (https://www.linkedin.com/in/oliviavoler/)
